public class deductK {
    public static void deductK(int M, int K) {
        for (int i = K; i < M; i++) {
            if (i == 0) {
                System.out.print("M ");
            } else if (i == 1) {
                System.out.print("M-k ");
            } else if (i > 1) {
                System.out.print("M-"+i+"k ");

            }
        }
    }
    public static void main(String[] args) {
        deductK(6,0);
    }
}
