public class makeUpwardRightTriangle {
    public static void makeUpwardRightTriangle(int w) {
        for (int i = 1; i <= w; i++){
            for (int j = 1 ; j <= i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        makeUpwardRightTriangle(4);
    }
}
