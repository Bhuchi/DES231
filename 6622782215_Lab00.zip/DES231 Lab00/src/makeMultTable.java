public class makeMultTable {
    public static void makeMultTable(int M) {
        for (int i =0; i < 12; i++) {
            if (i == 1) {
                System.out.println(i + " " + "M");
            } else if (i > 1) {
                System.out.println(i + " " + i + "M");
            } else if (i == 0) {
                System.out.println("X" + " " + "M");
            }
        }
    }
    public static void main(String[] args) {
        makeMultTable(12);
    }
}
