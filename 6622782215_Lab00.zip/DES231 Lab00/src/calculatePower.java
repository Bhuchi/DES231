public class calculatePower {
    public static int calculatePower(int base, int exponent) {
        int result = 1;
        for (int i = 0; i < exponent; i++){
            result *= base;
        }
        return result;
    }
    public static void main(String[] args) {
        int result = calculatePower(2,3) ;
        System.out.println(result);
    }
}
