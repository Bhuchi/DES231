public class makeDownwardRightTriangle {
    public static void makeDownwardRightTriangle(int w) {
        for (int i = w; i >= 0; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        makeDownwardRightTriangle(4);
    }
}
